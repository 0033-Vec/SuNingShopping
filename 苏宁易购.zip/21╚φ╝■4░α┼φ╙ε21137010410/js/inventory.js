// 准备一个数组，用于选项卡的切换,假装是后台的数据
var data = [
    {
        title: '精选',
        imgUrl: '../imgs/c-select1.png',
        details: [
            { href: 'http://www.baidu.com', content: '畅呼吸新格调，极简风空气净化器' },
            { href: 'http://www.baidu.com', content: '8公斤洗烘一体机，让您随时洁净出门' },
            { href: 'http://www.baidu.com', content: '全面屏带领手机潮流，逼格十足' },
            { href: 'http://www.baidu.com', content: '风冷无霜冰箱，保鲜除霜更省心' },
            { href: 'http://www.baidu.com', content: '大屏平板电视，4K画质清晰逼真' },
            { href: 'http://www.baidu.com', content: '欧式触控油烟机，还您无油烟厨房' },
            { href: 'http://www.baidu.com', content: '全面屏手机，视野开阔外形美翻' },
            { href: 'http://www.baidu.com', content: '高性能内存条，助力游戏不卡顿' },
            { href: 'http://www.baidu.com', content: '护腕鼠标垫，让办公党告别鼠标手' },
            { href: 'http://www.baidu.com', content: '笔记本平板二合一，躺着也实用' },
            { href: 'http://www.baidu.com', content: '童鞋拒闷脚，搜罗走心透气大牌' },
            { href: 'http://www.baidu.com', content: '免清洗，自净芯高温清洁功能烟机' }
        ]
    },
    {
        title: '家电', imgUrl: '../imgs/c-select2.png', details: [
            { href: 'http://www.baidu.com', content: '风冷无霜大容量，冰箱也是储物箱' },
            { href: 'http://www.baidu.com', content: '高清视觉盛宴，智能电视来助力' },
            { href: 'http://www.baidu.com', content: '做饭不愁，一个电磁炉全搞定' },
            { href: 'http://www.baidu.com', content: '对付闷热，强劲落地扇带给你清爽' },
            { href: 'http://www.baidu.com', content: '一级节能空调，全天开启不心疼' },
            { href: 'http://www.baidu.com', content: '房租小户，美菱迷你冰箱恰到好处' },
            { href: 'http://www.baidu.com', content: '小屏游戏不过瘾，大屏电视尽兴玩' },
            { href: 'http://www.baidu.com', content: '大家电足够省电才能安心使用！' },
            { href: 'http://www.baidu.com', content: '智能机器人，有效防碰撞吸力大' },
            { href: 'http://www.baidu.com', content: '消灭油烟，侧吸式烟灶套装更给力' },
            { href: 'http://www.baidu.com', content: '拒频繁分洗，大容量洗衣机更省时' },
            { href: 'http://www.baidu.com', content: '租房族消暑，移动空调免拆装烦恼' },
            { href: 'http://www.baidu.com', content: '夏日省电享美味，变频冰箱最擅长' },
        ]
    },
    {
        title: '酷机', imgUrl: '../imgs/c-select3.png', details: [
            { href: 'http://www.baidu.com', content: '头戴式耳机，听音乐更享受' },
            { href: 'http://www.baidu.com', content: '游戏达人必备，VR眼镜更震撼' },
            { href: 'http://www.baidu.com', content: '培养天才孩子，从儿童早教机开始' },
            { href: 'http://www.baidu.com', content: '运动蓝牙耳机，你的晨跑好搭档' },
            { href: 'http://www.baidu.com', content: '玩游戏不被扰，入手游戏模式手机' },
            { href: 'http://www.baidu.com', content: '自拍美颜手机，留住你精彩瞬间' },
            { href: 'http://www.baidu.com', content: '轻薄办公笔记本，操作流畅无延迟' },
            { href: 'http://www.baidu.com', content: '电竞超流畅，5G游戏手机不卡顿' },
            { href: 'http://www.baidu.com', content: '户外运动者忠实可靠的腕上伙伴' },
            { href: 'http://www.baidu.com', content: '多功能音响，享受高品质声音' },
            { href: 'http://www.baidu.com', content: '舒适便捷，蓝牙耳机开车更舒心' },
            { href: 'http://www.baidu.com', content: '畅呼吸新格调，极简风空气净化器' }
        ]
    },
    {
        title: '超市', imgUrl: '../imgs/c-select4.png', details: [
            { href: 'http://www.baidu.com', content: '防痱驱蚊虫的清凉舒爽花露水' },
            { href: 'http://www.baidu.com', content: '捕捉吃货的水果，吃的新鲜又健康' },
            { href: 'http://www.baidu.com', content: '居家适用的温和滋养护发素' },
            { href: 'http://www.baidu.com', content: '清爽控油的温和去屑洗发水' },
            { href: 'http://www.baidu.com', content: '易上色不飞粉的混色百搭眼影盘' },
            { href: 'http://www.baidu.com', content: '居家常备的高效除菌消毒液' },
            { href: 'http://www.baidu.com', content: '去屑止痒有一手，秀发有颜更健康' },
            { href: 'http://www.baidu.com', content: '色香味俱全，即食肉类零食解嘴馋' },
            { href: 'http://www.baidu.com', content: '低调双肩背包，数码产品轻松装' },
            { href: 'http://www.baidu.com', content: '好吃的巧克力甜点，谁能不爱' },
            { href: 'http://www.baidu.com', content: '口感丝滑浓郁的坚果巧克力' }
        ]
    },
    {
        title: '穿搭', imgUrl: '../imgs/c-select5.png', details: [
            { href: 'http://www.baidu.com', content: '夏季来一件雪纺衫，祛暑更轻巧' },
            { href: 'http://www.baidu.com', content: '更减龄和实穿，牛仔裙个性出彩' },
            { href: 'http://www.baidu.com', content: 'Polo衫耍酷，老单品新时髦' },
            { href: 'http://www.baidu.com', content: '约会这样搭，让你看起来超甜' },
            { href: 'http://www.baidu.com', content: '男装防晒衣，时尚又防嗮' },
            { href: 'http://www.baidu.com', content: '精致小心机，蕾丝内裤添风情' },
            { href: 'http://www.baidu.com', content: '时尚好搭配的手表为造型增光添彩' },
            { href: 'http://www.baidu.com', content: '柔软连体衣，让萌宝出门倍吸睛' },
            { href: 'http://www.baidu.com', content: '夏日泳衣合集，去泳池玩耍就买它' },
            { href: 'http://www.baidu.com', content: '风格统一，文胸套装释放内在魅力' },
            { href: 'http://www.baidu.com', content: '智能手表彰显魅力为你的品味加分' },
            { href: 'http://www.baidu.com', content: '清新配饰，让你看起来仙气感满满' }
        ]
    }
]


// 创建对应的分类选项
function selectText(data) {
    var contentSelect = document.getElementsByClassName('content-select')[0]
    // console.log(data)
    for (let i = 0; i < data.length; i++) {

        var li = document.createElement('li')
        li.innerHTML = `
                <img src="${data[i].imgUrl}">
                <p>${data[i].title}</p>
        `
        i == 0 ? li.className = 'active' : ''

        li.onclick = function(){
            indexGetDetails(i,data)
            
            // 给当前点击的元素设置active类名
            this.className = 'active'
            
            // 通过自己找到父级在找父级下面的所有子元素对象
            var sibling = this.parentNode.children
            // console.log(sibling)
            for(let j=0;j<sibling.length;j++){
                // 排除自己，给其他的兄弟元素将类名清除
                if(sibling[j] !== this){
                    sibling[j].className = ''
                }
            }
        }

        contentSelect.appendChild(li)
    }

}

selectText(data)

// 更具传递进来的下标，取出对应的值
function indexGetDetails(index,data){
    console.log(index)
    var datas = data[index].details
    // console.log(datas)

    var contentDetails = document.getElementsByClassName('content-details')[0]
    contentDetails.innerHTML = ''
    for(var i=0;i<datas.length;i++){
        var p = document.createElement('p')
        p.innerHTML = `<a href="${datas[i].href}">${datas[i].content}</a>`

        contentDetails.appendChild(p)
    }
}

indexGetDetails(0,data)